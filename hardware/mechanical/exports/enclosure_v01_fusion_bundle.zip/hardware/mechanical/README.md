# Maquette 3D du boîtier et des cartes

Étude d'encombrement 0.1 du 4 novembre 2026. Boîtier nu proposé : **145 × 100 × 115 mm** (largeur × hauteur × profondeur), hors bouton, prises et câbles. La maquette reprend les PCB A de 110 × 75 mm et B de 90 × 65 mm, avec leur épaisseur de 1,6 mm et les positions du fichier `../placement.json`.

## Fichiers à ouvrir

- **`exports/enclosure_printed_parts.step` : fichier à privilégier pour travailler sur l'impression. Exactement trois composants : coque/supports/clips intégrés, berceau B/clips intégrés et panneau arrière/clips intégrés. Un seul solide connecté par composant ; aucune enveloppe électronique dans ce fichier.**
- `exports/enclosure_printed_parts_exploded.step` : les mêmes trois pièces en vue éclatée.
- `exports/enclosure_assembled.step` : assemblage de référence en position. L'arborescence distingue maintenant cinq groupes : pièces imprimées, carte A, carte B, afficheur/encodeur et passe-paroi/faisceaux. Les enveloppes électroniques servent seulement à vérifier les dégagements, elles ne sont pas à imprimer.
- `exports/enclosure_exploded.step` : B et son berceau reculés de 50 mm, panneau arrière déposé de 85 mm. Les positions éclatées ne représentent pas les longueurs de câbles.
- `exports/enclosure_assembled.glb` : version de visualisation avec couleurs.
- `exports/preview_assembled.png`, `preview_exploded.png`, `preview_rear.png`, `preview_clips.png` : rendus issus de la géométrie 3D.
- `exports/preview_lcd_mount.png` : détail annoté du maintien du LCD, A et B masquées ; le support est coloré en orange pour le distinguer de la façade, mais appartient au même solide imprimé que la coque.
- `exports/parts/` : trois pièces de boîtier séparées en STEP et STL : coque/supports fixes, berceau B, panneau arrière.
- `exports/validation.json` : contrôles géométriques et liste des volumes représentés.

Fusion 360 prend en charge les [fichiers STEP](https://help.autodesk.com/view/fusion360/ENU/?caas=caas%2Fsfdcarticles%2Fsfdcarticles%2FFile-formats-supported-by-Fusion-360.html). Importer l'assemblage STEP, en millimètres. Les solides sont repris dans Fusion ; **l'historique des opérations paramétriques CadQuery ne devient pas un historique natif Fusion**. Aucun fichier `.f3d` n'est fourni. L'import a été relu avec OpenCascade, pas exécuté dans Fusion sur cette machine.

Les sources paramétriques sont `build_enclosure.py` et `enclosure_parameters.json`. Les positions des cartes et composants viennent du JSON d'implantation. Une modification directe dans Fusion ne se répercute pas automatiquement dans ces sources.

La correction d'organisation des exports ne modifie pas la géométrie. Les parois, supports et clips de la coque étaient déjà réunis en un solide ; le grand nombre de composants du premier export provenait des références électroniques ajoutées au même niveau. Le fichier limité aux trois pièces évite cette confusion dans Fusion.

## Pièces et accès

La coque est ouverte à l'arrière, avec supports intégrés du LCD et de A. Le LCD est retenu sur son propre PCB de référence ; il ne porte pas A. Les faces composants de A et de B sont à 45 et 85 mm de la face avant extérieure. Les composants et les fiches JST se dirigent vers l'arrière.

Pour le LCD, le chemin de maintien est : PCB de l'afficheur → appuis/pochettes et clips du cadre → ponts imprimés → coque. Deux poches basses portent le PCB ; deux crochets supérieurs le retiennent vers l'arrière ; le cadre fournit l'appui vers l'avant et les butées latérales. Le montage se fait depuis l'intérieur : engager le bord inférieur, rabattre le module contre son appui, puis enclencher les languettes supérieures. Elles se soulèvent pour démonter le module. Aucun clip ne doit prendre appui sur le verre, le rétroéclairage ou les composants du backpack. La position des contacts et l'épaisseur du logement restent à adapter au module réel.

La demande de glissières autour des PCB et de clips latéraux constitue une évolution du berceau à concevoir : la maquette actuelle utilise encore les poches basses et les clips supérieurs décrits ici. Le rendu de détail clarifie la fixation LCD existante ; il ne prétend pas avoir réalisé cette évolution de rails pour A/B.

Le berceau B est indépendant, posé dans des guides haut/bas et arrêté en avant. Deux petites poignées latérales permettent de le tirer par l'arrière. Il reprend les appuis sur les bandes de bord de PCB de 4 mm prévues dans KiCad. Le panneau arrière fermé limite son déplacement vers l'arrière par une butée, sans vis.

Chaque support de carte comprend deux poches basses fixes et deux languettes supérieures de retenue. Les languettes ont un crochet à rampe, un bras de départ de 16 mm et une épaisseur de 1,2 mm ; jeu arrière de logement de PCB de 0,4 mm. Elles se soulèvent pour dégager le bord supérieur du PCB. Ce sont des géométries de départ, **sans validation de flexion, de fatigue ou de matériau**.

Le panneau arrière est une pièce séparée de 3 mm, avec lèvre de positionnement et deux clips latéraux. Les fenêtres latérales de la coque donnent accès aux clips pour les repousser vers l'intérieur puis retirer le panneau. La vérification d'extraction de B suppose le panneau et tous les faisceaux déjà retirés ; elle ne simule pas la déformation des clips du panneau.

Séquence de maintenance proposée :

1. Couper et débrancher l'alimentation externe.
2. Libérer les deux clips latéraux du panneau et le reculer prudemment, avec les câbles assez longs pour accéder à leurs terminaisons.
3. Déconnecter du PCB B les trois faisceaux A/B ainsi que l'alimentation, la charge et la sonde. Les presse-étoupes ne sont pas des prises électriques ; les câbles restent solidaires du panneau.
4. Tirer le berceau B vers l'arrière par ses poignées, sans déplacer la façade ni A.
5. Libérer les clips du berceau si l'on veut séparer le PCB B de son support.

L'accès USB de A reste interne, après ouverture et éventuellement retrait de B. Les chemins de faisceaux représentés sont indicatifs ; prévoir le mou de service et vérifier les rayons de courbure avec les vrais fils. La maquette ne qualifie pas la tenue à l'arrachement des câbles.

## Passages de paroi retenus

Choix utilisateur : **deux presse-étoupes** pour les câbles d'entrée 12 V et de chauffage, plus **une prise sonde à deux contacts**. Ils sont placés sur le panneau arrière, pas directement sur les PCB. Les JST-XH restent internes.

| Fonction | Réservation proposée | Perçage de l'étude | Centre x / z |
| --- | --- | --- | --- |
| Entrée 12 V | Presse-étoupe M12, corps/nut modélisé Ø20 mm | Ø12,5 mm | 22 / 75 mm |
| Chauffage | Presse-étoupe M12, corps/nut modélisé Ø20 mm | Ø12,5 mm | 22 / 35 mm |
| Sonde NTC | Prise circulaire 2 contacts, enveloppe type GX12-2 Ø17 mm | Ø12,4 mm | 108 / 85 mm |

Coordonnées : x depuis la gauche en vue de face du boîtier, z depuis le bas. **En regardant le panneau depuis l'extérieur à l'arrière, gauche et droite sont inversées** : sonde en haut à gauche, entrée 12 V en haut à droite, chauffage en bas à droite.

Les dimensions de ces pièces sont des **réservations réglables et non des références de perçage fabricant**. Les filetages, méplats, écrous et contacts sont simplifiés. Sélectionner les références exactes avec leur plage de serrage de câble et leur longueur de filetage pour une paroi de 3 mm, puis adapter les perçages avant impression du panneau final. Le connecteur sonde a été déplacé dans la maquette pour dégager le guide supérieur de B et la lèvre du panneau.

Le diamètre de câble représenté est de 5,5 mm pour puissance/chauffage et 3,5 mm pour la sonde. Il sert uniquement à visualiser les sorties ; le calibre électrique des conducteurs reste à dimensionner selon le courant.

## Contrôles effectués

Le générateur vérifie la validité des solides et le fait que chaque pièce de boîtier soit un seul solide connecté. Il vérifie par intersections BRep que les trois pièces plastiques et les volumes de PCB/composants/passe-paroi ne s'interpénètrent pas en position assemblée. Les contacts de surface sont admis. Les assemblages intentionnels de l'encodeur et du LCD ne sont pas interprétés comme des collisions à supprimer.

Pour B, le contrôle teste plusieurs positions de recul et une enveloppe rectangulaire conservatrice balayée sur **50 mm**. Celle-ci doit rester libre vis-à-vis de la coque et de A/LCD, une fois le panneau et les câbles retirés. Cela vérifie le dégagement géométrique du passage, sans simuler les mains, les outils ou les déformations.

L'export STEP est réimporté et contrôlé : solides valides, export non vide. Cela ne remplace pas un essai d'ouverture dans Fusion ni une qualification de fabrication. Les composants inconnus restent des volumes de réservation, et non des modèles fournisseur vérifiés. Ni les clips, ni la rigidité des guides, ni la tenue thermique ou RF ne sont qualifiés.

## Reproduire ou modifier

```powershell
uv run hardware/mechanical/build_enclosure.py
```

Le script déclare ses dépendances CadQuery 2.6.1 et Pillow ; `uv` gère l'environnement. Il régénère les exports et leurs rendus à partir des sources, sans modifier les fichiers KiCad. Conserver les sources du modèle comme référence si les exports sont ensuite modifiés dans Fusion.

Le JSON d'enveloppe et les paramètres mécaniques doivent rester cohérents. Pour changer la taille d'une carte ou sa position, modifier également l'étude d'implantation, ses supports et les vérifications. Ne pas diminuer arbitrairement la profondeur : les connecteurs, leurs écrous et les chemins de câbles occupent une partie du volume arrière.

## Avant une impression fonctionnelle

Les STL fournis servent à préparer une **impression d'essai d'ajustement**, pas une fabrication finale. La coque et ses supports intégrés comportent des surplombs : orientation, supports d'impression et éventuellement découpage de la coque restent à mettre au point. Imprimer d'abord un coupon de clip/logement avec le matériau et l'imprimante retenus, mesurer les PCB et essayer les références réelles des passe-paroi.

Les mesures du LCD avec backpack, de la DevKit et du buck peuvent encore modifier le boîtier. Le refroidissement, les distances aux pièces chaudes et la protection thermique devront être validés après définition de la puissance de chauffage.
