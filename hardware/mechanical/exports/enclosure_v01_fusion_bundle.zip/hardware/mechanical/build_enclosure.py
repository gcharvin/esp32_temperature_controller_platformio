# /// script
# requires-python = ">=3.11,<3.14"
# dependencies = ["cadquery==2.6.1", "pillow>=11,<12"]
# ///
"""Parametric solid mock-up, STEP/STL/glTF exports and actual-geometry previews.

Run: uv run hardware/mechanical/build_enclosure.py
Coordinates: x left->right, y front->rear, z bottom->top, millimetres.
STEP is a named solid assembly, not a native Fusion feature timeline.
"""
import json
from pathlib import Path
import math
import cadquery as cq

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
P=json.loads((HERE/'enclosure_parameters.json').read_text(encoding='utf-8'))
LAYOUT=json.loads((ROOT/'placement.json').read_text(encoding='utf-8'))
OUT=HERE/'exports';OUT.mkdir(exist_ok=True)
W,H,D,T=[P['case_mm'][key] for key in ('width','height','depth','wall')]
PARTS=[]
LCD_DETAIL=[]
COLORS={'shell':(.78,.82,.85),'rear':(.54,.64,.70),'tray':(.95,.64,.25),
        'pcb':(.10,.48,.34),'module':(.20,.24,.29),'connector':(.92,.90,.79),
        'chip':(.18,.20,.22),'lcd':(.08,.19,.26),'metal':(.68,.71,.74),
        'wire':(.22,.46,.82),'window':(.17,.51,.69)}

def box(x,y,z,w,d,h):
    assert min(w,d,h)>0
    return cq.Workplane('XY').box(w,d,h,centered=(False,False,False)).translate((x,y,z))

def cyl(x,y,z,r,length):
    return cq.Workplane(obj=cq.Solid.makeCylinder(r,length,cq.Vector(x,y,z),cq.Vector(0,1,0)))

def fuse(shapes):
    result=shapes[0]
    for shape in shapes[1:]:result=result.union(shape)
    return result.clean()

def add(name,shape,color,group,physical=True):
    if not shape.val().isValid():raise ValueError('Invalid '+name)
    PARTS.append({'name':name,'shape':shape,'color':COLORS.get(color,color),'group':group,'physical':physical})
    return shape

def pcb_frame(x,zbottom,width,height,face):
    """Front support ring, lower fixed pockets and two upward-releasing springs."""
    thick=P['pcb_thickness_mm'];cl=P['clip_mm'];back=face-thick
    ring=box(x-4,back-3,zbottom-4,width+8,3,height+8)
    ring=ring.cut(box(x,back-3.1,zbottom+4,width,3.2,height-8))
    pieces=[ring]
    for local_x in (8,width-20):
        px=x+local_x;top=zbottom+height
        # Fixed lower pocket: 2 mm engagement, 0.4 mm clearance behind PCB.
        pieces.append(box(px,back-.2,zbottom-2,12,thick+cl['slot_clearance']+1.8,2))
        pieces.append(box(px,face+cl['slot_clearance'],zbottom,12,1.6,2))
        # Root touches the upper ring; the arm has an air gap behind the ring.
        root=px-8;length=cl['arm_length']
        pieces.append(box(root,back-.5,top+.4,2,thick+2.5,1.8))
        pieces.append(box(root,back+.6,top+.4,length,thick+1.4,cl['arm_thickness']))
        # Ramped hook: its rear slope allows insertion toward the front.
        a=face+cl['slot_clearance'];b=face+2
        hook=(cq.Workplane('YZ').polyline([(a,top-cl['engagement']),
               (b,top+.4),(b,top+.4+cl['arm_thickness']),
               (a,top+.4+cl['arm_thickness'])]).close().extrude(3)
               .translate((root+length-3,0,0)))
        pieces.append(hook)
    return fuse(pieces)

def frame_bridges(x,zbottom,width,height,face):
    back=face-P['pcb_thickness_mm']
    pieces=[]
    for z in (zbottom-4,zbottom+height+1):
        pieces.append(box(T-.5,back-2.7,z,x-4+1-(T-.5),2.4,3))
        pieces.append(box(x+width+3,back-2.7,z,W-T+.5-(x+width+3),2.4,3))
    return pieces

def main():
    front=P['rear_panel_mm']['thickness'];rear_y=D-front
    # Open-back shell, integral front and side/top/bottom walls.
    shell=box(0,0,0,W,rear_y,H).cut(box(T,T,T,W-2*T,rear_y-T+.1,H-2*T))
    win=P['lcd_window_mm']
    shell=shell.cut(box(win['center_x']-win['width']/2,-.1,win['center_z']-win['height']/2,
                        win['width'],T+.2,win['height']))
    enc=LAYOUT['assembly']['encoder_center_x_y_mm'];encz=H-enc[1]
    shell=shell.cut(cyl(enc[0],-.1,encz,3.6,T+.2))
    # Rear-panel release windows. Hooks are pressable from the outside.
    for x in (-.1,W-T-.1):shell=shell.cut(box(x,98,45.5,T+.2,8,9))
    # Independent LCD support, using the same releasable retention principle.
    lcd_frame=pcb_frame(8,28,98,60,15.1)
    lcd_mount=fuse([lcd_frame]+frame_bridges(8,28,98,60,15.1))
    front_slice=shell.intersect(box(0,0,0,W,24,H)).cut(lcd_mount)
    LCD_DETAIL.extend([
        {'name':'Facade_cutaway','shape':front_slice,'color':COLORS['shell'],'group':'lcd_detail'},
        {'name':'LCD_mount_integral_with_shell','shape':lcd_mount,'color':COLORS['tray'],'group':'lcd_detail'}])
    # A fixed support. PCB touches only the reserved upper/lower edge bands.
    ax,ay,aface=LAYOUT['assembly']['A_board_origin_x_y_d_mm'];az=H-ay-75
    a_frame=pcb_frame(ax,az,110,75,aface)
    shell=fuse([shell,lcd_frame,a_frame]+frame_bridges(8,28,98,60,15.1)+frame_bridges(ax,az,110,75,aface))
    # B support is a separate removable carrier; slide direction is +y.
    bx,by,bface=LAYOUT['assembly']['B_board_origin_x_y_d_mm'];bz=H-by-65
    tray=pcb_frame(bx,bz,90,65,bface)
    tray=fuse([tray,box(bx-7,bface-3,bz+23,4,21,10),box(bx+93,bface-3,bz+23,4,21,10)])
    gap=P['tray_clearance_mm'];fmin=bz-4;fmax=bz+65+4
    # Lateral guide ledges attach to the side walls and clear the rear lip.
    for z in (fmin-gap-2,fmax+gap):
        shell=shell.union(box(T-.5,78,z,bx+4-(T-.5),29,2))
        shell=shell.union(box(bx+86,78,z,W-T+.5-(bx+86),29,2))
    # Front stops, only at the carrier sides; board remains freely extractible.
    for x in (bx-4,bx+86):shell=shell.union(box(x,77.5,fmin-gap-.3,8,2.9,4+gap+.3))
    shell=shell.clean()
    # Rear panel: integral locating lip and two cantilever side latches.
    rc=P['rear_panel_mm']['lip_clearance'];ld=P['rear_panel_mm']['lip_depth']
    panel=box(0,rear_y,0,W,front,H)
    lip=box(T+rc,rear_y-ld,T+rc,W-2*(T+rc),ld,H-2*(T+rc))
    lip=lip.cut(box(T+rc+1.6,rear_y-ld-.1,T+rc+1.6,W-2*(T+rc+1.6),ld+.2,H-2*(T+rc+1.6)))
    arm=box(3.35,98,46,1.2,14,8)
    hook=cq.Workplane('XY').polyline([(3.35,98),(1.8,101),(1.8,104),(4.55,104),(4.55,98)]).close().extrude(8).translate((0,0,46))
    latch=arm.union(hook)
    panel=fuse([panel,lip,latch,latch.mirror('YZ').translate((W,0,0))])
    # Soft stop behind the carrier's right handle, gap at rest.
    panel=panel.union(box(bx+93,103.3,bz+24,4,rear_y-103.3,8))
    for port in P['bulkheads']:
        panel=panel.cut(cyl(port['center_x_mm'],rear_y-ld-.1,port['center_z_mm'],
                            port['hole_diameter_mm']/2,front+ld+.2))
    add('01_Main_shell_with_LCD_and_A_clips',shell,'shell','shell')
    add('02_B_removable_carrier_with_clips',tray,'tray','B')
    add('03_Rear_panel_with_latches',panel.clean(),'rear','rear')
    # Boards and all component envelopes come from the current placement study.
    for board in LAYOUT['boards']:
        name=board['name'];is_a=name=='pcb_a_display';group='A' if is_a else 'B'
        x,y,face=LAYOUT['assembly'][group+'_board_origin_x_y_d_mm']
        bw,bh,bt=board['board_mm'];bottom=H-y-bh
        add('PCB_'+group,box(x,face-bt,bottom,bw,bt,bh),'pcb',group)
        for row in board['components']:
            rx,ry,rw,rh=row['bounds_mm'];ref=row['reference']
            if ref in ('J1','J6','J7'):height=9.8;color='connector'
            elif row['footprint'] is None:
                height=20 if ref=='U1' else (10 if ref.startswith('J') else 8)
                color='module' if ref=='U1' else 'connector'
            else:height=1.5;color='chip'
            add(group+'_'+ref+'_ENVELOPE',box(x+rx,face,H-y-ry-rh,rw,height,rh),color,group)
    # LCD simplified reference assembly. Front optical opening is independent.
    add('LCD_PCB_98x60_TBD',box(8,13.5,28,98,1.6,60),'pcb','LCD')
    add('LCD_front_bezel_TBD',box(15,3.4,40,84,10.1,36),'lcd','LCD')
    add('LCD_backpack_TBD',box(51,15.1,34,45,12.9,20),'module','LCD')
    add('LCD_visible_screen',box(18.5,3.3,45.4,77,.1,25.2),'window','LCD')
    # Encoder shaft crosses its panel hole. Its body is a planning envelope.
    add('Encoder_body_TBD',box(enc[0]-8,3.2,encz-8,16,12,16),'module','LCD')
    add('Encoder_shaft',cyl(enc[0],-12,encz,3.2,15.2),'metal','LCD')
    add('Encoder_knob_TBD',cyl(enc[0],-17,encz,10,11),'module','LCD')
    for port in P['bulkheads']:
        x,z=port['center_x_mm'],port['center_z_mm'];radius=port['body_diameter_mm']/2
        stem_r=6;inside=port['inside_depth_mm'];outside=port['outside_depth_mm']
        body=fuse([cyl(x,D-inside,z,stem_r,inside+3),cyl(x,rear_y-3,z,radius,3),
                   cyl(x,D,z,radius,outside)])
        bore=port['cable_diameter_mm']/2+.4
        body=body.cut(cyl(x,D-inside-.1,z,bore,inside+outside+.2))
        add('BULKHEAD_'+port['name']+'_TBD',body,'metal' if 'PROBE' in port['name'] else 'module','rear')
        add('CABLE_'+port['name'],cyl(x,D-inside,z,port['cable_diameter_mm']/2,inside+outside+12),'wire','rear',False)
    # Three A/B bundle paths, only indicative routing, not minimum bend radii.
    paths=[[(102,54.8,76),(138,62,76),(138,100,76),(55,100,29),(55,94.8,29)],
           [(102,54.8,60),(138,64,60),(138,101,60),(74,101,29),(74,94.8,29)],
           [(96,54.8,43),(138,66,55),(138,102,55),(96,102,29),(96,94.8,29)]]
    for i,path in enumerate(paths,1):
        segments=[]
        for start,end in zip(path,path[1:]):
            v=cq.Vector(*end)-cq.Vector(*start)
            segments.append(cq.Workplane(obj=cq.Solid.makeCylinder(1.1,v.Length,cq.Vector(*start),v.normalized())))
        add(f'BUNDLE_AB_{i}_SCHEMATIC',fuse(segments),'wire','wire',False)
    validate_export()
    render_previews()

def validate_export():
    assembled=cq.Assembly(name='Laboratory_controller_fit_study_01')
    exploded=cq.Assembly(name='Exploded_fit_study_01')
    printed=cq.Assembly(name='Boitier_3_pieces_a_imprimer')
    printed_exploded=cq.Assembly(name='Boitier_3_pieces_vue_eclatee')
    print_names={'01_Main_shell_with_LCD_and_A_clips':'01_Coque_supports_et_clips_integres',
                 '02_B_removable_carrier_with_clips':'02_Berceau_B_et_clips_integres',
                 '03_Rear_panel_with_latches':'03_Panneau_arriere_et_clips_integres'}
    groups={key:cq.Assembly(name=label) for key,label in [
        ('plastic','01_Pieces_imprimees'),('A','02_Carte_A_reference'),
        ('B','03_Carte_B_reference'),('LCD','04_Afficheur_encodeur_reference'),
        ('external','05_Passe_paroi_et_faisceaux_reference')]}
    partsdir=OUT/'parts';partsdir.mkdir(exist_ok=True)
    summary={'status':'unqualified fit mock-up, not production design','parts':[],'collisions_mm3':[],
             'coordinates':'x left-right, y front-rear, z bottom-top (mm)',
             'case_mm':P['case_mm'],'bulkheads':P['bulkheads']}
    for part in PARTS:
        s=part['shape'];name=part['name'];vol=s.val().Volume()
        assert vol>0 and s.val().isValid(),name
        group='plastic' if name in print_names else part['group'] if part['group'] in ('A','B','LCD') else 'external'
        groups[group].add(s,name=name,color=cq.Color(*part['color']))
        shift=50 if part['group']=='B' else (85 if part['group']=='rear' else 0)
        if part['group']!='wire':exploded.add(s.translate((0,shift,0)),name=name,color=cq.Color(*part['color']))
        summary['parts'].append({'name':name,'volume_mm3':round(vol,3),'solids':len(s.val().Solids()),'group':part['group']})
        if name.startswith(('01_','02_','03_')):
            assert len(s.val().Solids())==1,(name,'print part is disconnected',[(round(a.Volume(),2),[round(v,2) for v in (a.BoundingBox().xmin,a.BoundingBox().ymin,a.BoundingBox().zmin,a.BoundingBox().xmax,a.BoundingBox().ymax,a.BoundingBox().zmax)]) for a in s.val().Solids()])
            cq.exporters.export(s,str(partsdir/(name+'.step')))
            cq.exporters.export(s,str(partsdir/(name+'.stl')),tolerance=.15,angularTolerance=.15)
            printed.add(s,name=print_names[name],color=cq.Color(*part['color']))
            printed_exploded.add(s.translate((0,shift,0)),name=print_names[name],color=cq.Color(*part['color']))
    # Exact BRep intersection of plastics, boards and component envelopes.
    # Adjacent encoder shaft/knob/body and nested LCD screen are intentional mates.
    plastic=[p for p in PARTS if p['name'].startswith(('01_','02_','03_'))]
    others=[p for p in PARTS if p['physical'] and p not in plastic]
    for a in plastic:
        for b in plastic+others:
            if a is b:continue
            if b in plastic and a['name']>b['name']:continue
            overlap=a['shape'].val().intersect(b['shape'].val()).Volume()
            if overlap>1e-4:summary['collisions_mm3'].append([a['name'],b['name'],round(overlap,5)])
    for a,b in [('PCB_A','PCB_B')]:
        sa=next(p['shape'] for p in PARTS if p['name']==a)
        sb=next(p['shape'] for p in PARTS if p['name']==b)
        assert sa.val().intersect(sb.val()).Volume()<1e-5
    b_parts=[p for p in PARTS if p['group']=='B' and p['physical']]
    b_envelope=cq.Compound.makeCompound([p['shape'].val() for p in b_parts]).BoundingBox()
    swept=box(b_envelope.xmin,b_envelope.ymin,b_envelope.zmin,
              b_envelope.xlen,b_envelope.ylen+50,b_envelope.zlen)
    # B and its carrier can translate 50 mm rearward after panel/cables removal.
    fixed=[p for p in PARTS if p['group'] in ('shell','A','LCD')]
    for obstacle in fixed:
        volume=swept.val().intersect(obstacle['shape'].val()).Volume()
        if volume>1e-4:summary['collisions_mm3'].append(['B_swept_bounding_box_0_to_50',obstacle['name'],round(volume,5)])
    for distance in (0,10,25,50):
        for moving in [p for p in PARTS if p['group']=='B' and p['physical']]:
            shape=moving['shape'].translate((0,distance,0))
            for obstacle in fixed:
                vol=shape.val().intersect(obstacle['shape'].val()).Volume()
                if vol>1e-4:summary['collisions_mm3'].append(['B_extraction_'+str(distance),moving['name'],obstacle['name'],round(vol,5)])
    (OUT/'validation.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    if summary['collisions_mm3']:raise AssertionError(summary['collisions_mm3'])
    for group in groups.values():assembled.add(group)
    assembled.export(str(OUT/'enclosure_assembled.step'))
    exploded.export(str(OUT/'enclosure_exploded.step'))
    assembled.export(str(OUT/'enclosure_assembled.glb'))
    printed.export(str(OUT/'enclosure_printed_parts.step'))
    printed_exploded.export(str(OUT/'enclosure_printed_parts_exploded.step'))
    imported_printed=cq.importers.importStep(str(OUT/'enclosure_printed_parts.step'))
    print_solids=imported_printed.val().Solids()
    assert len(print_solids)==3 and all(s.isValid() for s in print_solids)
    expected_volume=sum(part['shape'].val().Volume() for part in PARTS if part['name'] in print_names)
    assert math.isclose(imported_printed.val().Volume(),expected_volume,rel_tol=1e-8)
    summary['printed_parts_STEP']={'file':'enclosure_printed_parts.step','components':list(print_names.values()),'solid_count':3,'one_connected_solid_per_print_part':True}
    # Round-trip the exchange format, including checks against accidental empty exports.
    reimport=cq.importers.importStep(str(OUT/'enclosure_assembled.step'))
    assert reimport.val().isValid() and len(reimport.val().Solids())>=len(PARTS)
    summary['STEP_round_trip_solids']=len(reimport.val().Solids())
    summary['B_extraction_samples_mm']=[0,10,25,50]
    summary['B_continuous_extraction_check']='Conservative swept bounding box clear from 0 to 50 mm, rear panel and all cables removed'
    summary['STEP_volume_mm3']=round(reimport.val().Volume(),3)
    summary['fusion_import_tested']=False
    (OUT/'validation.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print('STEP/STL/GLB exported; BRep collision and extraction samples passed.')

def render_previews():
    import vtk
    from PIL import Image,ImageDraw,ImageFont
    def actor(part,shift=0,opacity=1):
        verts,triangles=part['shape'].val().tessellate(.3,.2)
        points=vtk.vtkPoints()
        for v in verts:points.InsertNextPoint(v.x,v.y+shift,v.z)
        cells=vtk.vtkCellArray()
        for tri in triangles:
            cells.InsertNextCell(3)
            for idx in tri:cells.InsertCellPoint(idx)
        mesh=vtk.vtkPolyData();mesh.SetPoints(points);mesh.SetPolys(cells)
        normals=vtk.vtkPolyDataNormals();normals.SetInputData(mesh);normals.SetFeatureAngle(50)
        mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(normals.GetOutputPort())
        a=vtk.vtkActor();a.SetMapper(mapper);a.GetProperty().SetColor(*part['color'])
        a.GetProperty().SetOpacity(opacity);a.GetProperty().SetSpecular(.2);a.GetProperty().SetSpecularPower(35)
        return a
    for mode,camera in [('assembled',(230,-260,175)),('exploded',(260,330,210)),('rear',(72,400,50)),('clips',(175,245,145)),('lcd_mount',(185,155,140))]:
        renderer=vtk.vtkRenderer();renderer.SetBackground(.94,.96,.97)
        scene=LCD_DETAIL+[p for p in PARTS if p['name'].startswith('LCD_')] if mode=='lcd_mount' else PARTS
        for part in scene:
            if mode=='clips' and part['group']!='B':continue
            if mode=='exploded' and (part['group']=='wire' or not part['physical']):continue
            shift=(50 if part['group']=='B' else 85 if part['group']=='rear' else 0) if mode=='exploded' else 0
            alpha=.15 if mode=='exploded' and part['group']=='shell' else 1
            renderer.AddActor(actor(part,shift,alpha))
        cam=renderer.GetActiveCamera();cam.SetPosition(*camera);cam.SetFocalPoint(85 if mode=='clips' else 72,12 if mode=='lcd_mount' else 85 if mode=='clips' else 90 if mode=='exploded' else 52,58 if mode=='lcd_mount' else 50)
        cam.SetViewUp(0,0,1);cam.ParallelProjectionOn();renderer.ResetCamera();cam.Zoom(1.0 if mode=='lcd_mount' else 1.12)
        window=vtk.vtkRenderWindow();window.SetOffScreenRendering(1);window.SetSize(1600,1100)
        window.SetMultiSamples(8);window.AddRenderer(renderer);window.Render()
        capture=vtk.vtkWindowToImageFilter();capture.SetInput(window);capture.Update()
        file=OUT/('preview_'+mode+'.png');writer=vtk.vtkPNGWriter();writer.SetFileName(str(file));writer.SetInputConnection(capture.GetOutputPort());writer.Write()
        window.Finalize()
        im=Image.open(file).convert('RGB');draw=ImageDraw.Draw(im)
        try:font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',28);small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',21)
        except OSError:font=small=ImageFont.load_default()
        titles={'assembled':'MAQUETTE 0.1 - facade / boitier assemble',
                'exploded':'MAQUETTE 0.1 - B extrait, panneau arriere depose',
                'rear':'PANNEAU ARRIERE - passages de paroi provisoires',
                'clips':'BERCEAU B - appuis bas et deux clips superieurs liberables',
                'lcd_mount':'FIXATION DU LCD - vue depuis interieur, cartes A et B masquees'}
        draw.text((35,24),titles[mode],font=font,fill='#18313e')
        draw.text((35,1050),'Volumes de composants et connecteurs a confirmer - clips non qualifies - pas de fabrication finale',font=small,fill='#435966')
        if mode=='exploded':draw.text((35,75),'Coque transparente / PCB A vert / berceau B orange / panneau arriere gris',font=small,fill='#435966')
        if mode=='lcd_mount':
            draw.text((35,75),'Orange : support imprime AVEC la coque (pas une piece supplementaire). Vert : PCB du LCD.',font=small,fill='#435966')
            callouts=[((23,16.5,87),(900,160),'Clips hauts : empechent le retrait'),
                      ((22,16.7,29),(1050,900),'Poches basses : portent le PCB'),
                      ((124,12,90),(45,260),'Ponts solidaires de la coque')]
            for point,(tx,ty),label in callouts:
                renderer.SetWorldPoint(*point,1);renderer.WorldToDisplay();px,py,_=renderer.GetDisplayPoint();py=1100-py
                bounds=draw.textbbox((tx,ty),label,font=small);draw.rectangle((bounds[0]-8,bounds[1]-7,bounds[2]+8,bounds[3]+7),fill='#f0f5f7')
                sx=(bounds[0]+bounds[2])/2;sy=bounds[3]+10 if ty<py else bounds[1]-10
                draw.line([(sx,sy),(px,py)],fill='#18313e',width=2)
                draw.ellipse((px-5,py-5,px+5,py+5),fill='#e78722')
                draw.text((tx,ty),label,font=small,fill='#18313e')
        if mode=='rear':
            draw.text((35,75),'Vue exterieure : sonde a gauche, alimentation et chauffage a droite',font=small,fill='#435966')
            for port in P['bulkheads']:
                renderer.SetWorldPoint(port['center_x_mm'],D+port['outside_depth_mm'],port['center_z_mm'],1)
                renderer.WorldToDisplay();px,py,_=renderer.GetDisplayPoint()
                label={'POWER_12V':'ENTREE 12 V','HEATER':'CHAUFFAGE','NTC_PROBE':'SONDE 2 CONTACTS'}[port['name']]
                draw.text((px-85,1100-py-90),label,font=small,fill='#18313e')
        im.save(file)
    print('Rendered actual CAD geometry previews.')

if __name__=='__main__':main()
